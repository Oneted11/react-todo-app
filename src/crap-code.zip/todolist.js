import React,{Component} from 'react';

export default class TodoList extends Component {
	const todoItems = this.state.items.map(items,index);
	render(){
		return(<div>
		<ul>
			<li key = {index}>{todoItems}</li>
		</ul>			
		</div>);
	}
}