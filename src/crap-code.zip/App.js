import React, { Component } from 'react';
//import ReactDOM from 'react-dom';
import logo from './logo.svg';
import './App.css';
import TodoList from "./todolist.js"
class App extends Component {
constructor (props){
super (props);
this.state = {
  newItem : '',
  items : ['first','second']
}
onChange = (event) =>{
  this.setState({newItem:this.target.value});
}
onClick=(event)=>{
  event.preventDefault();
  this.setState({items:this.state.items.concat(this.state.newItem)});
}
}
render () {
  return (
    <div>
      <TodoList></TodoList>
      <input value = {this.state.newItem} onChange = {this.onChange.bind(this)}></input>
      <button onClick = {this.onClick.bind(this)}></button>
    </div>
    );
}
}


export default App;
